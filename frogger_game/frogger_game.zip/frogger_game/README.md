# frogger_game
# Instructions for the game #
* Use the up, down, left and right arrow keys to move across the game board.
The return key can be used to switch between character/player.Move the character to the water-block without hitting the killer lady bugs. Everytime
you reach the water block the score and level increases by 1.

# How to play #
* Clone or download the zip version of the file from github repository onto the local workstation.
* link to the github repo : https://github.com/sanyata88/frogger_game
* Open the browser window and open index.html from applications folder to start playing game.
